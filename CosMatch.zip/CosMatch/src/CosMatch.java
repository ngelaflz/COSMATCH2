import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.*;

public class CosMatch extends JFrame implements ActionListener, WindowListener {

	JLabel title, budgetPromp, eyesPrompt;
	JLabel never, rarley, sometimes, often;
	JLabel[] eyeQuestions;
	JLabel[] genResponses;
	//JLabel q1, q2, q3, q4, q5, q6;
	JPanel mainpanel = new JPanel();
	JPanel buttonspanel = new JPanel();
	JRadioButton [] rButtons;
	int [] eyeQuestionScores;
	JButton submit;
	
	//JRadioButton rb1, rb2, rb3, rb4, rb5, rb6, rb7, rb8, rb9, rb10, rb11, rb12, rb13, rb14, rb15, rb16;
	JCheckBox tb1, tb2, tb3;
	
	
	public static void main(String[] args) {
		new CosMatch();
	}

	@SuppressWarnings("deprecation")
	public CosMatch() {
		title = new JLabel("Customization Quiz");
		//budgetPrompt = new JLabel("What is you price range?");

		createButtonsPanel();
		
		//mainpanel = new JPanel();
		mainpanel.setLayout(new GridBagLayout());
		GridBagConstraints gc = new GridBagConstraints();
		gc.gridx = 0;
		gc.gridy = 0;
		mainpanel.add(title, gc);
		
		gc.gridx = 0;
		gc.gridy = 1;
		gc.gridheight = 4;
		//mainpanel.add(budgetPrompt, gc);
		mainpanel.hide();
		
		

		setContentPane(buttonspanel);
		setTitle("CosMatch");
		setSize(500, 300);		 
		setResizable(false);
		addWindowListener(this);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setLayout(null);
		setLocationRelativeTo(null);
	}
	
	public void createButtonsPanel(){

		eyesPrompt = new JLabel("How often do you use the following?");
		eyeQuestions = new JLabel[6];
		genResponses = new JLabel[4];
		rButtons = new JRadioButton[24];
		eyeQuestionScores = new int[eyeQuestions.length];
		
		eyeQuestions[0] =  new JLabel("Gel eyeliner");
		eyeQuestions[1] =  new JLabel("Liquid eyeliner");
		eyeQuestions[2] =  new JLabel("Smokey eyes");
		eyeQuestions[3] =  new JLabel("Eye glitter");
		eyeQuestions[4] =  new JLabel("Vibrant eye looks");
		eyeQuestions[5] =  new JLabel("Neutral eye looks");
		
		genResponses[0] = new JLabel("Never");
		genResponses[1] = new JLabel("Rarely");
		genResponses[2] = new JLabel("Sometimes");
		genResponses[3] = new JLabel("Always");
		
		
		buttonspanel.setLayout(new GridBagLayout());
		GridBagConstraints gc1 = new GridBagConstraints();
		
		for ( int i = 0; i < rButtons.length; i++) {
			rButtons[i] = new JRadioButton();
			rButtons[i].addActionListener(this);
		}


		ButtonGroup bg1 = new ButtonGroup();
		bg1.add(rButtons[0]);
		bg1.add(rButtons[1]);
		bg1.add(rButtons[2]);
		bg1.add(rButtons[3]);
		
		ButtonGroup bg2 = new ButtonGroup();
		bg2.add(rButtons[4]);
		bg2.add(rButtons[5]);
		bg2.add(rButtons[6]);
		bg2.add(rButtons[7]);
		
		ButtonGroup bg3 = new ButtonGroup();
		bg3.add(rButtons[8]);
		bg3.add(rButtons[9]);
		bg3.add(rButtons[10]);
		bg3.add(rButtons[11]);
		
		ButtonGroup bg4 = new ButtonGroup();
		bg4.add(rButtons[12]);
		bg4.add(rButtons[13]);
		bg4.add(rButtons[14]);
		bg4.add(rButtons[15]);
		
		ButtonGroup bg5 = new ButtonGroup();
		bg5.add(rButtons[16]);
		bg5.add(rButtons[17]);
		bg5.add(rButtons[18]);
		bg5.add(rButtons[19]);
		
		ButtonGroup bg6 = new ButtonGroup();
		bg6.add(rButtons[20]);
		bg6.add(rButtons[21]);
		bg6.add(rButtons[22]);
		bg6.add(rButtons[23]);
		
		gc1.gridx = 0;
		gc1.gridy = 0;
		//gc1.gridwidth = 2;
		
		buttonspanel.add(eyesPrompt, gc1);
		gc1.gridwidth = 1;
		for ( int i = 0; i < eyeQuestions.length; i++) {
			gc1.gridy = i+2;
			buttonspanel.add(eyeQuestions[i], gc1);
		}
		
		gc1.weightx = 1.25;
		gc1.weighty = 0;
		
		gc1.gridx = 1;
		gc1.gridy = 1;
		
		for ( int i = 0; i < genResponses.length; i++ ) {
			gc1.gridx = i+2;
			buttonspanel.add(genResponses[i], gc1);
		}
		
		int index = 0;
		gc1.gridx = 1;
		gc1.gridy = 2;
		for ( int i = 0; i < 6; i++) {
			gc1.gridy = i+2;
			for ( int j = 0; j < 4; j++ ) {
				gc1.gridx = j+2;
				buttonspanel.add(rButtons[index], gc1);
				index++;
			}
		}
		
		submit = new JButton("Submit");
		submit.addActionListener(this);
		gc1.gridy = 10;
		gc1.gridx = 0;
		gc1.gridwidth = 10;
		buttonspanel.add(submit, gc1);
		
		
		buttonspanel.setSize(500, 300);
		
	}
		

	@Override
	public void windowOpened(WindowEvent e) {}
	@Override
	public void windowClosing(WindowEvent e) {}
	@Override
	public void windowClosed(WindowEvent e) {	}
	@Override
	public void windowIconified(WindowEvent e) {}
	@Override
	public void windowDeiconified(WindowEvent e) {}
	@Override
	public void windowActivated(WindowEvent e) {}
	@Override
	public void windowDeactivated(WindowEvent e) {}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if ( e.getSource() == submit) {
			int count = 0;
			for ( int i = 0; i < rButtons.length; i++) {
				if ( rButtons[i].isSelected() && i % 4 == 0 ) //if first then
					eyeQuestionScores[count] = 0;
				else if ( rButtons[i].isSelected() && i % 4 == 1 ) //if second
					eyeQuestionScores[count] = 1;
				else if ( rButtons[i].isSelected() && i % 4 == 2 ) //if third
					eyeQuestionScores[count] = 2;
				else if ( rButtons[i].isSelected() && i % 4 == 3 ) //if fourth
					eyeQuestionScores[count] = 3; 
			}
			
			for ( int i = 0; i < eyeQuestions.length; i++ ) {
				System.out.println("Customer's "+eyeQuestions[i].getText()+" is\t"+ eyeQuestionScores[i]+".");
				
				
			}
		}
	}
	

}
